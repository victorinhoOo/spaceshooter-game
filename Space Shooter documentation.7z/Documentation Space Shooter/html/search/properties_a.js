var searchData=
[
  ['score_0',['Score',['../class_space_shooter_1_1model_1_1_the_game.html#a194ec0fff8a45259204bafe282c0fa10',1,'SpaceShooter.model.TheGame.Score'],['../class_space_shooter_1_1_res_1_1_strings.html#a6d93e4b004d798e0325cdd2e5a9bd455',1,'SpaceShooter.Res.Strings.Score']]],
  ['sound_1',['Sound',['../class_space_shooter_1_1_res_1_1_strings.html#ac0f7288bbb632b1dc8b7416cf958e4e0',1,'SpaceShooter::Res::Strings']]],
  ['spaceshooter_2',['SpaceShooter',['../class_space_shooter_1_1_res_1_1_strings.html#a6873240c955d07cc6b5760c349919d84',1,'SpaceShooter::Res::Strings']]]
];
