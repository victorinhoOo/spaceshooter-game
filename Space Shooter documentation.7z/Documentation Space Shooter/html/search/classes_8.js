var searchData=
[
  ['officer_0',['Officer',['../class_space_shooter_1_1model_1_1_ennemies_1_1_officer.html',1,'SpaceShooter::model::Ennemies']]]
];
