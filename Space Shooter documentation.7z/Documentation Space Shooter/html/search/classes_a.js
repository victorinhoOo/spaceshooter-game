var searchData=
[
  ['scoreitem_0',['ScoreItem',['../class_space_shooter_1_1view_1_1_high_scores_window_1_1_score_item.html',1,'SpaceShooter::view::HighScoresWindow']]],
  ['soldier_1',['Soldier',['../class_space_shooter_1_1model_1_1_ennemies_1_1_soldier.html',1,'SpaceShooter::model::Ennemies']]],
  ['strings_2',['Strings',['../class_space_shooter_1_1_res_1_1_strings.html',1,'SpaceShooter::Res']]]
];
