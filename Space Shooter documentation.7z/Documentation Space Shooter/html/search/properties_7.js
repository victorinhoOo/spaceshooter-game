var searchData=
[
  ['namesekip_0',['NamesEkip',['../class_space_shooter_1_1_res_1_1_strings.html#ace34db20948968b0db9bd4d8bbab72f2',1,'SpaceShooter::Res::Strings']]]
];
