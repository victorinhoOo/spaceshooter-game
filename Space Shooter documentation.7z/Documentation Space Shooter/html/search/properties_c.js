var searchData=
[
  ['yourscore_0',['YourScore',['../class_space_shooter_1_1_res_1_1_strings.html#ad9f3b9ce9430a52e696b9de5ee6c1456',1,'SpaceShooter::Res::Strings']]]
];
