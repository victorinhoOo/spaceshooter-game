var searchData=
[
  ['updatescore_0',['UpdateScore',['../class_space_shooter_1_1model_1_1_the_game.html#a553a2241271d058293ea56623373376b',1,'SpaceShooter.model.TheGame.UpdateScore()'],['../class_space_shooter_1_1view_1_1_game_window.html#a0deb4f16df7e1c1f6cf848dea452f32e',1,'SpaceShooter.view.GameWindow.UpdateScore()']]]
];
