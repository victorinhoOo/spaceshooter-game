var searchData=
[
  ['replay_0',['Replay',['../class_space_shooter_1_1_res_1_1_strings.html#a4e1b3f511f4dae93aca93201068579ea',1,'SpaceShooter::Res::Strings']]],
  ['resourcemanager_1',['ResourceManager',['../class_space_shooter_1_1_res_1_1_strings.html#aa4f494689c3297b10ea75d8628fc8430',1,'SpaceShooter::Res::Strings']]]
];
