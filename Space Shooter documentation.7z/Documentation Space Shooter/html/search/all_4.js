var searchData=
[
  ['framework_0',['Framework',['../class_space_shooter_1_1_res_1_1_strings.html#a443e930520cbee16ec94b24f9eef459b',1,'SpaceShooter::Res::Strings']]]
];
