var searchData=
[
  ['bonustype_0',['BonusType',['../namespace_space_shooter_1_1model_1_1_bonus.html#a2752c37c4489b9742167158c0817640c',1,'SpaceShooter::model::Bonus']]]
];
