var searchData=
[
  ['gamewindow_0',['GameWindow',['../class_space_shooter_1_1_res_1_1_strings.html#ae1ed9ae8871c606dcf988a4b0075fafd',1,'SpaceShooter::Res::Strings']]]
];
