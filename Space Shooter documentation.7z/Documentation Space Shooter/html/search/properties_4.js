var searchData=
[
  ['high_5fscores_0',['High_Scores',['../class_space_shooter_1_1_res_1_1_strings.html#a64b306d3e8eb1768890a2acd232e105d',1,'SpaceShooter::Res::Strings']]],
  ['highscores_1',['HighScores',['../class_space_shooter_1_1_res_1_1_strings.html#a782aaa7c5608de6e8f5f0a4cff271b17',1,'SpaceShooter::Res::Strings']]]
];
