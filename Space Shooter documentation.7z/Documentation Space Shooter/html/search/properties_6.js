var searchData=
[
  ['menu_0',['Menu',['../class_space_shooter_1_1_res_1_1_strings.html#aaabb2f2d9d683aad4f196d15ce6cbe01',1,'SpaceShooter::Res::Strings']]]
];
