var searchData=
[
  ['parameters_0',['Parameters',['../class_space_shooter_1_1_res_1_1_strings.html#a6dd64fd3df2a3231757f020aea5d0d6b',1,'SpaceShooter::Res::Strings']]],
  ['parameterstitle_1',['ParametersTitle',['../class_space_shooter_1_1_res_1_1_strings.html#afaea30bcf79267420f93593b7729598c',1,'SpaceShooter::Res::Strings']]],
  ['play_2',['Play',['../class_space_shooter_1_1_res_1_1_strings.html#aa4a7020fb42b8eb76c2fb920eff6141a',1,'SpaceShooter::Res::Strings']]],
  ['program_5fsounds_3',['Program_Sounds',['../class_space_shooter_1_1_res_1_1_strings.html#aa1042e2ba70b076f12fe09b19e33a3cc',1,'SpaceShooter::Res::Strings']]]
];
