var namespace_space_shooter_1_1model =
[
    [ "Bonus", "namespace_space_shooter_1_1model_1_1_bonus.html", "namespace_space_shooter_1_1model_1_1_bonus" ],
    [ "Ennemies", "namespace_space_shooter_1_1model_1_1_ennemies.html", "namespace_space_shooter_1_1model_1_1_ennemies" ],
    [ "Projectiles", "namespace_space_shooter_1_1model_1_1_projectiles.html", "namespace_space_shooter_1_1model_1_1_projectiles" ],
    [ "IWindow", "interface_space_shooter_1_1model_1_1_i_window.html", null ],
    [ "Player", "class_space_shooter_1_1model_1_1_player.html", "class_space_shooter_1_1model_1_1_player" ],
    [ "TheGame", "class_space_shooter_1_1model_1_1_the_game.html", "class_space_shooter_1_1model_1_1_the_game" ]
];