var annotated_dup =
[
    [ "IHM", "namespace_i_h_m.html", [
      [ "App", "class_i_h_m_1_1_app.html", "class_i_h_m_1_1_app" ],
      [ "MainWindow", "class_i_h_m_1_1_main_window.html", "class_i_h_m_1_1_main_window" ]
    ] ],
    [ "SpaceShooter", "namespace_space_shooter.html", [
      [ "model", "namespace_space_shooter_1_1model.html", [
        [ "Bonus", "namespace_space_shooter_1_1model_1_1_bonus.html", [
          [ "Bonus", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus.html", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus" ],
          [ "BonusShoot", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus_shoot.html", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus_shoot" ],
          [ "BonusSpeed", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus_speed.html", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus_speed" ]
        ] ],
        [ "Ennemies", "namespace_space_shooter_1_1model_1_1_ennemies.html", [
          [ "Asteroid", "class_space_shooter_1_1model_1_1_ennemies_1_1_asteroid.html", "class_space_shooter_1_1model_1_1_ennemies_1_1_asteroid" ],
          [ "Enemy", "class_space_shooter_1_1model_1_1_ennemies_1_1_enemy.html", "class_space_shooter_1_1model_1_1_ennemies_1_1_enemy" ],
          [ "General", "class_space_shooter_1_1model_1_1_ennemies_1_1_general.html", "class_space_shooter_1_1model_1_1_ennemies_1_1_general" ],
          [ "GeneratorEnemy", "class_space_shooter_1_1model_1_1_ennemies_1_1_generator_enemy.html", "class_space_shooter_1_1model_1_1_ennemies_1_1_generator_enemy" ],
          [ "Officer", "class_space_shooter_1_1model_1_1_ennemies_1_1_officer.html", "class_space_shooter_1_1model_1_1_ennemies_1_1_officer" ],
          [ "Soldier", "class_space_shooter_1_1model_1_1_ennemies_1_1_soldier.html", "class_space_shooter_1_1model_1_1_ennemies_1_1_soldier" ]
        ] ],
        [ "Projectiles", "namespace_space_shooter_1_1model_1_1_projectiles.html", [
          [ "Bullet", "class_space_shooter_1_1model_1_1_projectiles_1_1_bullet.html", null ],
          [ "Laser", "class_space_shooter_1_1model_1_1_projectiles_1_1_laser.html", "class_space_shooter_1_1model_1_1_projectiles_1_1_laser" ],
          [ "PlayerBullet", "class_space_shooter_1_1model_1_1_projectiles_1_1_player_bullet.html", "class_space_shooter_1_1model_1_1_projectiles_1_1_player_bullet" ],
          [ "Projectile", "class_space_shooter_1_1model_1_1_projectiles_1_1_projectile.html", "class_space_shooter_1_1model_1_1_projectiles_1_1_projectile" ]
        ] ],
        [ "IWindow", "interface_space_shooter_1_1model_1_1_i_window.html", null ],
        [ "Player", "class_space_shooter_1_1model_1_1_player.html", "class_space_shooter_1_1model_1_1_player" ],
        [ "TheGame", "class_space_shooter_1_1model_1_1_the_game.html", "class_space_shooter_1_1model_1_1_the_game" ]
      ] ],
      [ "Res", "namespace_space_shooter_1_1_res.html", [
        [ "Strings", "class_space_shooter_1_1_res_1_1_strings.html", null ]
      ] ],
      [ "view", "namespace_space_shooter_1_1view.html", [
        [ "GameWindow", "class_space_shooter_1_1view_1_1_game_window.html", "class_space_shooter_1_1view_1_1_game_window" ],
        [ "HighScoresWindow", "class_space_shooter_1_1view_1_1_high_scores_window.html", "class_space_shooter_1_1view_1_1_high_scores_window" ],
        [ "LooseWindow", "class_space_shooter_1_1view_1_1_loose_window.html", "class_space_shooter_1_1view_1_1_loose_window" ],
        [ "ParametersWindow", "class_space_shooter_1_1view_1_1_parameters_window.html", "class_space_shooter_1_1view_1_1_parameters_window" ]
      ] ]
    ] ]
];