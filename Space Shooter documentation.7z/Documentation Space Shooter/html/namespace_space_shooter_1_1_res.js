var namespace_space_shooter_1_1_res =
[
    [ "Strings", "class_space_shooter_1_1_res_1_1_strings.html", null ]
];