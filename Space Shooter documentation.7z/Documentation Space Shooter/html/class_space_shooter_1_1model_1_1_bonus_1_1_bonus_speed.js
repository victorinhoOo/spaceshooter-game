var class_space_shooter_1_1model_1_1_bonus_1_1_bonus_speed =
[
    [ "BonusSpeed", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus_speed.html#a389f43ba9b05655144e69d9ccf61f50c", null ]
];