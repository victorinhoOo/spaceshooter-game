var class_space_shooter_1_1model_1_1_ennemies_1_1_officer =
[
    [ "Officer", "class_space_shooter_1_1model_1_1_ennemies_1_1_officer.html#a014feb070147691e74ca420bff01713c", null ],
    [ "Animate", "class_space_shooter_1_1model_1_1_ennemies_1_1_officer.html#a66ca79712873fc3f585bd8c1161d059f", null ],
    [ "CollideEffect", "class_space_shooter_1_1model_1_1_ennemies_1_1_officer.html#a2bae84359c830d473018a1d65b3f37c9", null ],
    [ "ShootLaser", "class_space_shooter_1_1model_1_1_ennemies_1_1_officer.html#a3e81879cf191c79ece7271814f9bd5e5", null ]
];