var namespace_space_shooter_1_1model_1_1_bonus =
[
    [ "Bonus", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus.html", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus" ],
    [ "BonusShoot", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus_shoot.html", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus_shoot" ],
    [ "BonusSpeed", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus_speed.html", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus_speed" ],
    [ "BonusType", "namespace_space_shooter_1_1model_1_1_bonus.html#a2752c37c4489b9742167158c0817640c", [
      [ "Speed", "namespace_space_shooter_1_1model_1_1_bonus.html#a2752c37c4489b9742167158c0817640ca44877c6aa8e93fa5a91c9361211464fb", null ],
      [ "Shoot", "namespace_space_shooter_1_1model_1_1_bonus.html#a2752c37c4489b9742167158c0817640cacf4a0298c82a0d16c03788f8d0ce273c", null ]
    ] ]
];