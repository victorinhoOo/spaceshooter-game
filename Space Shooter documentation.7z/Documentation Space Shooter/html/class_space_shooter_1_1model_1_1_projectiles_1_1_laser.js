var class_space_shooter_1_1model_1_1_projectiles_1_1_laser =
[
    [ "Laser", "class_space_shooter_1_1model_1_1_projectiles_1_1_laser.html#a62eb488ee93a07e3a7b1294f57a52ab4", null ],
    [ "Animate", "class_space_shooter_1_1model_1_1_projectiles_1_1_laser.html#af493f11ba9aa864634857a1ca7c76568", null ]
];