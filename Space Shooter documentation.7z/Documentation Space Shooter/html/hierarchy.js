var hierarchy =
[
    [ "System.Windows.Application", null, [
      [ "IHM.App", "class_i_h_m_1_1_app.html", null ]
    ] ],
    [ "IUTGame.Game", null, [
      [ "SpaceShooter.model.TheGame", "class_space_shooter_1_1model_1_1_the_game.html", null ]
    ] ],
    [ "GameItem", null, [
      [ "SpaceShooter.model.Bonus.Bonus", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus.html", [
        [ "SpaceShooter.model.Bonus.BonusShoot", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus_shoot.html", null ],
        [ "SpaceShooter.model.Bonus.BonusSpeed", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus_speed.html", null ]
      ] ],
      [ "SpaceShooter.model.Ennemies.Enemy", "class_space_shooter_1_1model_1_1_ennemies_1_1_enemy.html", [
        [ "SpaceShooter.model.Ennemies.Asteroid", "class_space_shooter_1_1model_1_1_ennemies_1_1_asteroid.html", null ],
        [ "SpaceShooter.model.Ennemies.General", "class_space_shooter_1_1model_1_1_ennemies_1_1_general.html", null ],
        [ "SpaceShooter.model.Ennemies.Officer", "class_space_shooter_1_1model_1_1_ennemies_1_1_officer.html", null ],
        [ "SpaceShooter.model.Ennemies.Soldier", "class_space_shooter_1_1model_1_1_ennemies_1_1_soldier.html", null ]
      ] ],
      [ "SpaceShooter.model.Ennemies.GeneratorEnemy", "class_space_shooter_1_1model_1_1_ennemies_1_1_generator_enemy.html", null ],
      [ "SpaceShooter.model.Player", "class_space_shooter_1_1model_1_1_player.html", null ],
      [ "SpaceShooter.model.Projectiles.Projectile", "class_space_shooter_1_1model_1_1_projectiles_1_1_projectile.html", [
        [ "SpaceShooter.model.Projectiles.Bullet", "class_space_shooter_1_1model_1_1_projectiles_1_1_bullet.html", null ],
        [ "SpaceShooter.model.Projectiles.Laser", "class_space_shooter_1_1model_1_1_projectiles_1_1_laser.html", null ],
        [ "SpaceShooter.model.Projectiles.PlayerBullet", "class_space_shooter_1_1model_1_1_projectiles_1_1_player_bullet.html", null ]
      ] ]
    ] ],
    [ "IAnimable", null, [
      [ "SpaceShooter.model.Bonus.Bonus", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus.html", null ],
      [ "SpaceShooter.model.Ennemies.Enemy", "class_space_shooter_1_1model_1_1_ennemies_1_1_enemy.html", null ],
      [ "SpaceShooter.model.Ennemies.GeneratorEnemy", "class_space_shooter_1_1model_1_1_ennemies_1_1_generator_enemy.html", null ],
      [ "SpaceShooter.model.Player", "class_space_shooter_1_1model_1_1_player.html", null ],
      [ "SpaceShooter.model.Projectiles.Projectile", "class_space_shooter_1_1model_1_1_projectiles_1_1_projectile.html", null ]
    ] ],
    [ "System.Windows.Markup.IComponentConnector", null, [
      [ "IHM.MainWindow", "class_i_h_m_1_1_main_window.html", null ],
      [ "SpaceShooter.view.GameWindow", "class_space_shooter_1_1view_1_1_game_window.html", null ],
      [ "SpaceShooter.view.HighScoresWindow", "class_space_shooter_1_1view_1_1_high_scores_window.html", null ],
      [ "SpaceShooter.view.LooseWindow", "class_space_shooter_1_1view_1_1_loose_window.html", null ],
      [ "SpaceShooter.view.ParametersWindow", "class_space_shooter_1_1view_1_1_parameters_window.html", null ]
    ] ],
    [ "IKeyboardInteract", null, [
      [ "SpaceShooter.model.Player", "class_space_shooter_1_1model_1_1_player.html", null ]
    ] ],
    [ "SpaceShooter.model.IWindow", "interface_space_shooter_1_1model_1_1_i_window.html", [
      [ "SpaceShooter.view.GameWindow", "class_space_shooter_1_1view_1_1_game_window.html", null ],
      [ "SpaceShooter.view.HighScoresWindow", "class_space_shooter_1_1view_1_1_high_scores_window.html", null ],
      [ "SpaceShooter.view.LooseWindow", "class_space_shooter_1_1view_1_1_loose_window.html", null ]
    ] ],
    [ "SpaceShooter.view.HighScoresWindow.ScoreItem", "class_space_shooter_1_1view_1_1_high_scores_window_1_1_score_item.html", null ],
    [ "SpaceShooter.Res.Strings", "class_space_shooter_1_1_res_1_1_strings.html", null ],
    [ "System.Windows.Window", null, [
      [ "IHM.MainWindow", "class_i_h_m_1_1_main_window.html", null ],
      [ "SpaceShooter.view.GameWindow", "class_space_shooter_1_1view_1_1_game_window.html", null ],
      [ "SpaceShooter.view.HighScoresWindow", "class_space_shooter_1_1view_1_1_high_scores_window.html", null ],
      [ "SpaceShooter.view.LooseWindow", "class_space_shooter_1_1view_1_1_loose_window.html", null ],
      [ "SpaceShooter.view.ParametersWindow", "class_space_shooter_1_1view_1_1_parameters_window.html", null ]
    ] ]
];