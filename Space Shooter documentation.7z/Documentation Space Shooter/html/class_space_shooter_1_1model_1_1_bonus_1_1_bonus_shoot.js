var class_space_shooter_1_1model_1_1_bonus_1_1_bonus_shoot =
[
    [ "BonusShoot", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus_shoot.html#aa33b3c04ecf9123991b0ffc3dbc4c52b", null ]
];