var class_space_shooter_1_1model_1_1_the_game =
[
    [ "InitItems", "class_space_shooter_1_1model_1_1_the_game.html#ad6de2f43ae493b5482904ae1f73980d2", null ],
    [ "RunWhenLoose", "class_space_shooter_1_1model_1_1_the_game.html#ac133477ab7a7f44052834c21f964fda8", null ],
    [ "UpdateScore", "class_space_shooter_1_1model_1_1_the_game.html#a553a2241271d058293ea56623373376b", null ],
    [ "Score", "class_space_shooter_1_1model_1_1_the_game.html#a194ec0fff8a45259204bafe282c0fa10", null ]
];