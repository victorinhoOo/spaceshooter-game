var namespace_space_shooter =
[
    [ "model", "namespace_space_shooter_1_1model.html", "namespace_space_shooter_1_1model" ],
    [ "Res", "namespace_space_shooter_1_1_res.html", "namespace_space_shooter_1_1_res" ],
    [ "view", "namespace_space_shooter_1_1view.html", "namespace_space_shooter_1_1view" ]
];