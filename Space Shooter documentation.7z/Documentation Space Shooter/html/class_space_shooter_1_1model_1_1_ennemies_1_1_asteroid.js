var class_space_shooter_1_1model_1_1_ennemies_1_1_asteroid =
[
    [ "Asteroid", "class_space_shooter_1_1model_1_1_ennemies_1_1_asteroid.html#a736c532376c5f744ae522b41b02f7623", null ],
    [ "Animate", "class_space_shooter_1_1model_1_1_ennemies_1_1_asteroid.html#a52416c91b6d191b262cddc133a851a2c", null ]
];