var class_space_shooter_1_1model_1_1_player =
[
    [ "Player", "class_space_shooter_1_1model_1_1_player.html#a4cbd156f1fa837a94c7135a08b3fbc97", null ],
    [ "Animate", "class_space_shooter_1_1model_1_1_player.html#a1e420339410b0e5d4155c2ff7fa095f3", null ],
    [ "CollideEffect", "class_space_shooter_1_1model_1_1_player.html#aab84c99940d92e25e9b7acdbc63f6432", null ],
    [ "KeyDown", "class_space_shooter_1_1model_1_1_player.html#a7c535c113ec23dc1e9e655865addea07", null ],
    [ "Shoot", "class_space_shooter_1_1model_1_1_player.html#a844a941e314b8eb8332ea76da6d3eb32", null ]
];