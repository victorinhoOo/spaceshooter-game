var class_i_h_m_1_1_main_window =
[
    [ "InitializeComponent", "class_i_h_m_1_1_main_window.html#abb28d813e5ac4462741682dc0468719d", null ],
    [ "InitializeComponent", "class_i_h_m_1_1_main_window.html#abb28d813e5ac4462741682dc0468719d", null ],
    [ "InitializeComponent", "class_i_h_m_1_1_main_window.html#abb28d813e5ac4462741682dc0468719d", null ],
    [ "InitializeComponent", "class_i_h_m_1_1_main_window.html#abb28d813e5ac4462741682dc0468719d", null ],
    [ "OpenParametersButton_Click", "class_i_h_m_1_1_main_window.html#aa7de8f0e5e62d53edb9736d2df15b4e8", null ],
    [ "PlayButton_Click", "class_i_h_m_1_1_main_window.html#a54660ddb525f079615074ae0661dbee5", null ]
];