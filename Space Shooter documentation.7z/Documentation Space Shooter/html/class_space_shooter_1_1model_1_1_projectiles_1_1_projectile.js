var class_space_shooter_1_1model_1_1_projectiles_1_1_projectile =
[
    [ "Projectile", "class_space_shooter_1_1model_1_1_projectiles_1_1_projectile.html#addaf91fa8db80d765d498444fc144d1f", null ],
    [ "TypeName", "class_space_shooter_1_1model_1_1_projectiles_1_1_projectile.html#a1a3348e8ccb39b895e7d4784d4668b78", null ]
];