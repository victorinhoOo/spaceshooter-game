var namespaces_dup =
[
    [ "IHM", "namespace_i_h_m.html", "namespace_i_h_m" ],
    [ "SpaceShooter", "namespace_space_shooter.html", "namespace_space_shooter" ]
];