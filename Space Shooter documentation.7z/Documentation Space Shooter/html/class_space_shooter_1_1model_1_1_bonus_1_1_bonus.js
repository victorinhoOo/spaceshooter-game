var class_space_shooter_1_1model_1_1_bonus_1_1_bonus =
[
    [ "Bonus", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus.html#afe8eecf83d7fa1d85a38b808c1d7c408", null ],
    [ "Animate", "class_space_shooter_1_1model_1_1_bonus_1_1_bonus.html#a6433d42c259b3b57f1c25a9d5e9419a0", null ]
];