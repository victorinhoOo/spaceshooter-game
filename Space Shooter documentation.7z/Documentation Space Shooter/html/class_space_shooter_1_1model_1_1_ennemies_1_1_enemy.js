var class_space_shooter_1_1model_1_1_ennemies_1_1_enemy =
[
    [ "Enemy", "class_space_shooter_1_1model_1_1_ennemies_1_1_enemy.html#aab4432c1076cbf941c69b671c706ad25", null ],
    [ "GenerateBonus", "class_space_shooter_1_1model_1_1_ennemies_1_1_enemy.html#a4213c15b9a210b3778b91b6ad2b1d679", null ]
];